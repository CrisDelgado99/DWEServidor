<?php
session_start();

include './libreria/funciones.php';
include './conexion.php';

$usuario = $_SESSION['usuario'];
$idUsuario = $_SESSION['idUsuario'];

$frase = fraseDia(rand(1, 14));

//CREAR UNA NUEVA TAREA____________________________________________________________________________________________
if (isset($_POST['tarea']) && isset($_POST['descripcion'])) {
    if ($_POST['tarea'] == '' || $_POST['descripcion'] == '') {
        //Mensaje de error
        $mensaje = 'Por favor, introduzca todos los datos.';
    } else if(strlen($_POST['tarea']) > 20 || strlen($_POST['descripcion']) > 200){
        $mensaje = 'Ha escrito demasiados caracteres.';
    } else {
        //Mensaje de éxito
        $mensaje = 'Datos introducidos correctamente.';

        //Insertar los datos en la tabla tarea------------------------------------------------------------------
        $statement = $connexion->prepare('INSERT INTO tarea(`titulo`, `descripcion`) VALUES(:tarea, :descripcion)');
        $statement->execute(array(
            ':tarea' =>  $_POST['tarea'],
            ':descripcion' => $_POST['descripcion'],
        ));

        //Seleccionar el id de la tarea introducida--------------------------------------------------------
        $statement = $connexion->prepare('SELECT MAX(id) AS max_id FROM tarea');
        $statement->execute();

        $result = $statement->fetch(PDO::FETCH_ASSOC);

        $maxId = $result['max_id'];

        //Insertar los id de usuario y tarea en usuarios_tarea-----------------------------------------------
        $statement = $connexion->prepare('INSERT INTO usuarios_tarea(`usuario`, `tarea`) VALUES(:idUsuario, :idTarea)');
        $statement->execute(array(
            ':idUsuario' => $idUsuario,
            'idTarea' => $maxId
        ));
    }

    //Mandar alerta que dice si se ha introducido la tarea correctamente
    echo "<script>alert('$mensaje');</script>";
} 
//BORRAR DATOS________________________________________________________________________________________________
if (isset($_POST['borrar'])) {
    $idBorrar = $_POST['borrar'];

    //idBorrar es el id de usuarios_tarea, necesito encontrar el id de tarea.
    $idTareaBorrar = encontrarIdTarea($idBorrar);

    //borrar de la tabla usuarios_tarea
    $statement = $connexion->prepare('DELETE FROM usuarios_tarea WHERE usuarios_tarea.id = :idBorrar');
    $statement->execute(array(':idBorrar' => $idBorrar));

    //borrar de la tabla tarea
    $statement = $connexion->prepare('DELETE FROM tarea WHERE tarea.id = :idBorrar');
    $statement->execute(array(':idBorrar' => $idTareaBorrar));
}

//MODIFICAR TAREA______________________________________________________________________________________________
if(isset($_POST['idTarea']) && isset($_POST['tareaModif']) && isset($_POST['descripcionModif'])){
    if(($_POST['tareaModif'] == '') || ($_POST['descripcionModif'] == '')){
        $mensajeModif = 'Por favor, para modificar la tarea escriba nuevos valores.'; 

    } else if(strlen($_POST['tareaModif']) > 20 || strlen($_POST['descripcionModif']) > 200){
        $mensajeModif = 'Ha escrito más caracteres de los aceptados.';
    } else {
        $mensajeModif = 'Se han podido realizar los cambios en la tarea.';

        $idTarea = $_POST['idTarea'];
        $tareaModif = $_POST['tareaModif'];
        $descripcionModif = $_POST['descripcionModif'];

        $statement = $connexion->prepare('UPDATE tarea
                                        SET titulo = :tareaModif, descripcion = :descripcionModif
                                        WHERE id = :idTarea');
        $statement->bindParam(':idTarea', $idTarea, PDO::PARAM_INT);
        $statement->bindParam(':tareaModif', $tareaModif, PDO::PARAM_STR);
        $statement->bindParam(':descripcionModif', $descripcionModif, PDO::PARAM_STR);

        $statement->execute();
    }

    echo '<script>
            alert(' . $mensajeModif . ');
        </script>';
}

//PREPARAR LA BÚSQUEDA PARA IMPRIMIR LAS TAREAS PENDIENTES DEL USUARIO_______________________________________________________   
$statement = $connexion->prepare('SELECT * FROM tarea t JOIN usuarios_tarea ut ON(t.id = ut.tarea) WHERE ut.usuario LIKE :idUsuario');
$statement->bindParam(':idUsuario', $idUsuario, PDO::PARAM_STR);
$statement->execute();
$arrFila = $statement->fetchAll(PDO::FETCH_ASSOC);
//El resto de esta sección se encuentra en una función en la librería, y se la llama desde contenido.view.php para que se imprima donde
//se debe imprimir



require './views/contenido.view.php';



?>
<? ?>