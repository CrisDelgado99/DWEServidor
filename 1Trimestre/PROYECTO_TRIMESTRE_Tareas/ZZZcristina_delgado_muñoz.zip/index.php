<?
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notelink - Index</title>
    <link rel="stylesheet" href="./css/modificar.css">
</head>
<body>
    <div id="padrePopup">
        <div id="popup">
            <div>
            <h1>Notelink:</h1>
    <h2>Ten todas tus notas en el mismo sitio.</h2>

    <p>¿Tienes cuenta? <a href="./login.php">Accede</a></p>
    <p>¿No tienes cuenta? <a href="./registro.php">Regístrate</a></p>
            </div>

        </div>
    </div>

</body>
</html>