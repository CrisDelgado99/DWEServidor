<?php
session_start();

include './conexion.php';

        
        if(isset($_POST['inpUsuario']) && isset($_POST['inpPassword1'])){
            $usuario = $_POST['inpUsuario'];
            $password = hash('sha512', $_POST['inpPassword1']);

            $statement = $connexion->prepare('SELECT usuario, password, id FROM usuarios WHERE usuario = :usuario AND password = :password');
            $statement->bindParam(':usuario', $usuario, PDO::PARAM_STR);
            $statement->bindParam(':password', $password, PDO::PARAM_STR);
            $statement->execute();

            $resultado = $statement->fetch(PDO::FETCH_ASSOC);
            

            if($resultado){
                $_SESSION['idUsuario'] = $resultado['id'];
                $_SESSION['usuario'] = $usuario;
                header('location: contenido.php');  
                exit(); 
            } else {     
                echo 'Nombre o contraseña incorrectos.';
            }

            
        }




        require 'views/login.view.php';
    ?>



