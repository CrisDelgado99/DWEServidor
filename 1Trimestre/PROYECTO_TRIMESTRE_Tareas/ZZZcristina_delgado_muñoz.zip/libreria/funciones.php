<?php


//Esta función devuelve la frase del día
function fraseDia($numRandom)
{
    switch ($numRandom) {
        case 1:
            return 'Tú puedes con todo';
        case 2:
            return 'Cuando sientas que tienes demasiado que hacer, divide y vencerás';
        case 3:
            return 'Hoy va a ser un buen día';
        case 4:
            return 'Estás consiguiendo lo que te propones';
        case 5:
            return 'Ve paso por paso, día por día';
        case 6:
            return 'Cada pequeño paso te acerca a tu gran meta';
        case 7:
            return 'La paciencia y la persistencia son claves para el éxito';
        case 8:
            return 'Aprovecha cada día, es una oportunidad para progresar';
        case 9:
            return 'Visualiza tu éxito, luego trabaja por ello';
        case 10:
            return 'Cada desafío es una oportunidad para crecer';
        case 11:
            return 'Sigue esforzándote, tus metas valen la pena';
        case 12:
            return 'Cree en ti, vales mucho';
        case 13:
            return 'Sé el cambio que esperas en tu vida';
        case 14:
            return 'Quiérete. A veces las cosas no salen como queremos y no pasa nada.';
    }
}

//Esta función imprime las tareas del usuario en su tablón. Si no hay, dice que no hay tareas pendientes
function impTareasUsuario($arrFila){
    if (count($arrFila) > 0) {
        foreach ($arrFila as $fila) {
            echo '<tr>
                    <td class="tituTd"> '. $fila['titulo'] . '</td>
                    <td colspan="3">' . $fila['descripcion'] . '</td>
                    <td>
                        <form action="contenido.php" method="post">
                            <button type="submit" class="borrar" id="'. $fila['id']. '">x</button>
                            <input type="text" name="borrar" value="' . $fila['id'] . '" hidden>
                        </form>
                        <form action="modificar.php" method="post">
                            <button type="submit" class="modificar" id="'. $fila['id']. '">Modificar</button>
                            <input type="text" name="modificar" value="' . $fila['id'] . '" hidden>
                        </form>                   
                    </td>

                </tr>';
    
        }
    } else {
        echo '<tr>
                <td id="noTareas" colspan="6">No tienes tareas pendientes</td>
            </tr>';
    }
}

function encontrarIdTarea($idUsuaTar){
    include './conexion.php';

    $statement = $connexion->prepare('SELECT tarea AS idTarea FROM usuarios_tarea WHERE usuarios_tarea.id = :idUsuaTar');
    $statement->execute(array(':idUsuaTar' => $idUsuaTar));
    $result = $statement->fetch(PDO::FETCH_ASSOC);

    return $result['idTarea'];
}

function imprimirMensaje($mensaje){
    echo '<p>' . $mensaje . '</p>';
}

function usuarioExiste($usuario){
    include './conexion.php';

    $statement = $connexion->prepare('SELECT usuario FROM usuarios WHERE usuarios.usuario = :usuario');
    $statement->execute(array(':usuario' => $usuario));
    $result = $statement->fetch(PDO::FETCH_ASSOC);

    return !empty($result);
}
