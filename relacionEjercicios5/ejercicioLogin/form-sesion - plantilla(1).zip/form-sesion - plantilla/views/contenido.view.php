<?
echo "Esta es la página de contenido que se abre cuando el usuario inicia sesión correctamente <br>";


?>
<a href="cerrarsesion.php">Cerrar sesion </a>