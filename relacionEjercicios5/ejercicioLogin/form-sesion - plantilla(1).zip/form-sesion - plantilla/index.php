<?
/**
 * En esta página se encuentra el código de la landing page del sitio. Se mostrará un enlace para iniciar sesión.
 * Modifica esta página y pon tu contenido.
 * 
 * Autor: Nombre Apellidos
 * 
 */
echo "<h1>Pantalla inicio</h1>";

?>
